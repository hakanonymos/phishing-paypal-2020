<?php


// You can change these any time.

$panelusername = "admin";  //set your USER
$panelpassword = "admin"; // set your password


?>